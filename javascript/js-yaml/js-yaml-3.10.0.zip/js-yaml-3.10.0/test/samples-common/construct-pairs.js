'use strict';

module.exports = {
  'Block tasks': [
    [ 'meeting', 'with team.' ],
    [ 'meeting', 'with boss.' ],
    [ 'break', 'lunch.' ],
    [ 'meeting', 'with client.' ]
  ],
  'Flow tasks': [
    [ 'meeting', 'with team' ],
    [ 'meeting', 'with boss' ]
  ]
};
