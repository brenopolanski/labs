'use strict';

module.exports = 'ascii string';
