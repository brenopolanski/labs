'use strict';


module.exports = {
  emptyArray:  [],
  emptyObject: {}
};
