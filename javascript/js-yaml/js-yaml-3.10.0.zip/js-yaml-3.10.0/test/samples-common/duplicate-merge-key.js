'use strict';

module.exports = {
  x: 1,
  y: 2,
  foo: 'bar',
  z: 3,
  t: 4
};
