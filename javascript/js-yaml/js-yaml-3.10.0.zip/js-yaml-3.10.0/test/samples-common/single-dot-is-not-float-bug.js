'use strict';

module.exports = '.';
